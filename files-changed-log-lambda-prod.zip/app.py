import json
import os
import hmac
import hashlib

GITHUB_WEBHOOK_SECRET = os.environ.get("GITHUB_WEBHOOK_SECRET")


def lambda_handler(event, context):

    github_signature = event["headers"]["X-Hub-Signature"]

    if not verify_github_signature(event["body"], github_signature):
        return {
            "statusCode": 403,
            "body": "Invalid GitHub signature. Request not from GitHub."
        }

    payload = json.loads(event["body"])

    if payload["action"] == "closed" and payload["pull_request"]["merged"]:
        # Extract the list of changed files
        changed_files = [file["filename"] for file in payload["pull_request"]["head"]["repo"]["contents"]]

        # Log the changed files (you can replace this with your preferred logging mechanism)
        print("Merged Pull Request - Changed Files:")
        for file in changed_files:
            print(file)

        return {
            "statusCode": 200,
            "body": "Webhook received, and merged pull request file names logged."
        }

    return {
        "statusCode": 200,
        "body": "Webhook received, but no action taken."
    }


def verify_github_signature(payload, signature):
    # Compute the expected hash based on the payload and the secret
    expected_hash = "sha1=" + hmac.new(GITHUB_WEBHOOK_SECRET.encode(), payload.encode(), hashlib.sha1).hexdigest()

    # Compare the computed hash with the signature from GitHub
    return hmac.compare_digest(expected_hash, signature)
